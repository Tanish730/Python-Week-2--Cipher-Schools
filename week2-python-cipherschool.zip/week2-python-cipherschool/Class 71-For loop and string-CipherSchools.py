# name= "satakratu"
# for i in name:
  #   print(i)

# 1256 --> 1+2+5+6
n = input("Enter a number: ")
total= 0
for i in n:
    total+= int(i)
print(total)