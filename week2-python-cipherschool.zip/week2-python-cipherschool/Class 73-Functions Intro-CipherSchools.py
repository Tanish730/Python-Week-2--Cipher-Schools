# functions
def add_two(num1,num2):
    return num1+num2
# total= add_two(10,4)
# print(total)
# print(add_two(10,4)# )
# a=int(input("Enter first number: "))
# b=int(input("Enter first number: "))
# total= add_two(a,b)
# print(total)
first_name=input("Type first name: ")
last_name=input("Type last name: ")
total= add_two(first_name,last_name)
print(total)